var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
      .when("/home", {
        templateUrl : "viewss/home.html"
    })


    .when("/course", {
        templateUrl : "viewss/course.html"
    })
  
    .when("/class", {
        templateUrl : "views/class.html"
    })

    .when("/contact", {
        templateUrl : "views/contact.html"
    })
    .when("/register", {
        templateUrl : "viewss/register.html",
        
    })
    .when("/login", {
        templateUrl : "views/login.html"
    });
});
       

          
        